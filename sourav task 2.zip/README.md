# Sourav v2 — Dark & Elegant Responsive Version

This package contains the dark & elegant responsive transformation done for Sourav's site.
Files included:
- responsive_index.html
- styles/responsive_dark.min.css (production)
- styles/responsive_dark.css (readable)
- images/optimized/* (small/medium/large versions)

Notes:
- Images were optimized and resized to 400px, 800px, 1600px widths (JPEG quality 80).
- Test in Chrome DevTools (iPhone SE → Desktop) in portrait/landscape.
- For production: serve with gzip/brotli and add caching headers.