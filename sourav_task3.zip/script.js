/* ==========================
   Task 3 Interactivity Script
   ========================== */

/* === 1. Light / Dark Mode Toggle === */
const toggleBtn = document.getElementById('themeToggle');

toggleBtn.addEventListener('click', () => {
  document.body.classList.toggle('dark-mode');

  const isDark = document.body.classList.contains('dark-mode');
  toggleBtn.setAttribute('aria-pressed', isDark);
  toggleBtn.textContent = isDark ? '☀️ Light Mode' : '🌙 Dark Mode';
});

/* === 2. Modal Popup (Image Zoom) === */
const images = document.querySelectorAll('.zoom-img');
const modal = document.getElementById('modal');
const modalImg = document.getElementById('modalImg');
const closeModal = document.getElementById('closeModal');

images.forEach((img) => {
  img.addEventListener('click', () => {
    modal.classList.remove('hidden');
    modalImg.src = img.src;
    modal.setAttribute('aria-hidden', 'false');
    modalImg.focus();
  });
});

closeModal.addEventListener('click', () => {
  modal.classList.add('hidden');
  modal.setAttribute('aria-hidden', 'true');
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    modal.classList.add('hidden');
    modal.setAttribute('aria-hidden', 'true');
  }
});

/* === 3. Form Validation === */
const form = document.getElementById('contactForm');
const formMessage = document.getElementById('formMessage');

form.addEventListener('submit', (e) => {
  e.preventDefault();

  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const message = document.getElementById('message').value.trim();

  try {
    if (name === '' || email === '' || message === '') {
      throw new Error('Please fill in all fields.');
    }
    if (!email.includes('@') || !email.includes('.')) {
      throw new Error('Please enter a valid email address.');
    }

    formMessage.textContent = 'Message sent successfully!';
    formMessage.style.color = 'green';
    form.reset();
  } catch (err) {
    formMessage.textContent = err.message;
    formMessage.style.color = 'red';
    console.error('Validation error:', err);
  }
});